Implement cache-oblivious transposition of square matrices.

The Python version requires the NumPy module for storing the matrix
in memory efficiently.

Source code templates can be found in [git](https://gitlab.kam.mff.cuni.cz/datovky/assignments/-/tree/master).
